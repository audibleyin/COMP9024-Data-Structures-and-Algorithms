
# 《数据结构与算法之美》

本文档是[《数据结构与算法之美》](http://gk.link/a/108GK)的学习笔记和个人编写的python实现的相关代码。

每一课最后出的思考题均有相应的解答和**python代码实现**。

[![stars](https://badgen.net/github/stars/xiao-xiaoming/DataStructure-BeautyOfAlgorithm?icon=github&color=4ab8a1)](https://github.com/xiao-xiaoming/DataStructure-BeautyOfAlgorithm) [![forks](https://badgen.net/github/forks/xiao-xiaoming/DataStructure-BeautyOfAlgorithm?icon=github&color=4ab8a1)](https://github.com/xiao-xiaoming/DataStructure-BeautyOfAlgorithm)

如果本文档对您有用，期待您进入github项目主页点击右上角Star :star: 给予关注！谢谢拉！

还可以分享给您身边更多的小伙伴！:kissing_heart:

[GitHub](<https://github.com/xiao-xiaoming/DataStructure-BeautyOfAlgorithm>)
[开始阅读](README.md)

